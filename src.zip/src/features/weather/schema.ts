/**
 * Zod schema for the OpenWeatherMap OneCall 3.0 response.
 *
 * Validates the shape of `current`, `hourly[]` and `daily[]` objects.
 * Some fields (visibility, wind_gust, rain) are marked optional because
 * the API omits them when not applicable.
 *
 * The inferred TypeScript type `WeatherData` is exported for use
 * throughout the app.
 */
import { z } from "zod";

export const weatherSchema = z.object({
  lat: z.number(),
  lon: z.number(),
  timezone: z.string(),
  timezone_offset: z.number(),
  current: z.object({
    dt: z.number(),
    sunrise: z.number(),
    sunset: z.number(),
    temp: z.number(),
    feels_like: z.number(),
    pressure: z.number(),
    humidity: z.number(),
    dew_point: z.number(),
    uvi: z.number(),
    clouds: z.number(),
    visibility: z.number().optional(), // <-- Made optional
    wind_speed: z.number(),
    wind_deg: z.number(),
    wind_gust: z.number().optional(),
    weather: z.array(z.object({
      id: z.number(),
      main: z.string(),
      description: z.string(),
      icon: z.string(),
    })),
    rain: z.object({ '1h': z.number() }).optional(),
  }),
  hourly: z.array(z.object({
    dt: z.number(),
    temp: z.number(),
    feels_like: z.number(),
    pressure: z.number(),
    humidity: z.number(),
    dew_point: z.number(),
    clouds: z.number(),
    visibility: z.number().optional(), // <-- Made optional (THIS WAS THE BUG!)
    wind_speed: z.number(),
    wind_deg: z.number(),
    wind_gust: z.number().optional(),
    weather: z.array(z.object({
      id: z.number(),
      main: z.string(),
      description: z.string(),
      icon: z.string(),
    })),
    pop: z.number(),
    rain: z.object({ '1h': z.number() }).optional(),
  })),
  daily: z.array(z.object({
    dt: z.number(),
    sunrise: z.number(),
    sunset: z.number(),
    temp: z.object({
      day: z.number(),
      min: z.number(),
      max: z.number(),
      night: z.number(),
      eve: z.number(),
      morn: z.number(),
    }),
    feels_like: z.object({
      day: z.number(),
      night: z.number(),
      eve: z.number(),
      morn: z.number(),
    }),
    pressure: z.number(),
    humidity: z.number(),
    dew_point: z.number(),
    wind_speed: z.number(),
    wind_deg: z.number(),
    wind_gust: z.number().optional(),
    weather: z.array(z.object({
      id: z.number(),
      main: z.string(),
      description: z.string(),
      icon: z.string(),
    })),
    clouds: z.number(),
    pop: z.number(),
    rain: z.number().optional(),
    uvi: z.number(),
  })),
});

export type WeatherData = z.infer<typeof weatherSchema>;
